# Stub unicorn package - satisfies anisette's `unicorn` dependency on Android,
# where the real CPU-emulator wheel does not exist and cannot be cross-compiled
# by Chaquopy. The app only ever uses RemoteAnisetteProvider; the local
# Anisette emulator (the only code that instantiates Uc) is never reached.

UC_ARCH_ARM = 1
UC_ARCH_ARM64 = 2
UC_ARCH_X86 = 4

UC_MODE_ARM = 0
UC_MODE_32 = 1 << 2
UC_MODE_64 = 1 << 3

UC_HOOK_CODE = 1 << 1
UC_HOOK_BLOCK = 1 << 3
UC_HOOK_MEM_READ_UNMAPPED = 1 << 4
UC_HOOK_MEM_WRITE_UNMAPPED = 1 << 5
UC_HOOK_MEM_FETCH_UNMAPPED = 1 << 6

UC_MEM_WRITE_UNMAPPED = 19
UC_MEM_FETCH_UNMAPPED = 20

from .unicorn import Uc

__all__ = [
    "UC_ARCH_ARM", "UC_ARCH_ARM64", "UC_ARCH_X86",
    "UC_MODE_ARM", "UC_MODE_32", "UC_MODE_64",
    "UC_HOOK_CODE", "UC_HOOK_BLOCK",
    "UC_HOOK_MEM_READ_UNMAPPED", "UC_HOOK_MEM_WRITE_UNMAPPED", "UC_HOOK_MEM_FETCH_UNMAPPED",
    "UC_MEM_WRITE_UNMAPPED", "UC_MEM_FETCH_UNMAPPED",
    "Uc",
]
